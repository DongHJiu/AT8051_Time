////#include <REGX52.H>

////typedef unsigned int u16;	  
////typedef unsigned char u8;

////sbit LSA=P2^2;
////sbit LSB=P2^3;
////sbit LSC=P2^4;


////char num=0;
////u8 DisplayData[8];
////u8 code smgduan[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};

////u8 hour_HS;
////u8 hour_H;
////u8 hour_L;
////u8 minute_H;
////u8 minute_L;
////u8 second_H;
////u8 second_L;

////void delay(u16 i)
////{
////	while(i--);	
////}

////void datapros() 	 
////{
////	if(second_L > 9)
////	{
////		second_L = 0;
////		second_H++;
////	}
////	if(second_H > 5)
////	{
////		second_L = 0;
////		second_H = 0;
////		minute_L++;
////	}
////	if(minute_L > 9)
////	{
////		second_L = 0;
////		second_H = 0;
////		minute_L = 0;
////		minute_H++;
////	}
////	if(minute_H > 5)
////	{
////		second_L = 0;
////		second_H = 0;
////		minute_L = 0;
////		minute_H = 0;
////		hour_L++;
////		if(hour_HS > 0)
////		{
////			hour_HS++;
////		}
////		if(hour_HS == 4)
////		{
////			//ȫ��0
////		}			
////	}
////	if(hour_L > 9)
////	{
////		second_L = 0;
////		second_H = 0;
////		minute_L = 0;
////		minute_H = 0;
////		hour_L = 0;
////		hour_H++;
////	}	
////	if(hour_H == 2)
////	{
////		second_L = 0;
////		second_H = 0;
////		minute_L = 0;
////		minute_H = 0;
////		hour_L = 0;
////		hour_HS = 1;
////	}		
////	
////	DisplayData[0] = 	smgduan[hour_H];
////	DisplayData[1] = 	smgduan[hour_L];		 
////	DisplayData[2] =  smgduan[minute_H];
////	DisplayData[3] = 	smgduan[minute_L];		
////	DisplayData[4] = 	smgduan[second_H];
////	DisplayData[5] =  smgduan[second_L];
////}

////void DigDisplay()
////{
////	u8 i;
////	for(i=0;i<8;i++)
////	{
////		switch(i)	 
////		{
////			case(0):
////				LSA=0;LSB=0;LSC=0; break;
////			case(1):
////				LSA=1;LSB=0;LSC=0; break;
////			case(2):
////				LSA=0;LSB=1;LSC=0; break;
////			case(3):
////				LSA=1;LSB=1;LSC=0; break;
////			case(4):
////				LSA=0;LSB=0;LSC=1; break;
////			case(5):
////				LSA=1;LSB=0;LSC=1; break;
////		}
////		P0=DisplayData[i];
////		delay(100); 
////		P0=0x00;
////	}		
////}

////void main(){
////	while(1){
////		datapros();	 
////		DigDisplay();
////	}
////}

