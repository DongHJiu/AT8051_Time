#ifndef __KEY_H
#define __KEY_H

int Function_Key1(void);
int Function_Key2(void);
int Function_Key3(void);
void delay(unsigned int i);

extern	unsigned char y;
extern  unsigned char hour_HSL;
extern  unsigned char hour_HS;
extern  unsigned char hour_H;
extern  unsigned char hour_L;
extern  unsigned char minute_H;
extern  unsigned char minute_L;
extern  unsigned char second_H;
extern  unsigned char second_L;

#endif
