#include <REGX52.H>
#include "intrins.h"


sbit Key_1 = P2^0;
sbit Key_2 = P2^1;
sbit Key_3 = P2^2;

typedef unsigned int u16;	  //���������ͽ�����������
typedef unsigned char u8;

u8 hour_HSL;
u8 hour_HS;
u8 hour_H;
u8 hour_L;
u8 minute_H;
u8 minute_L;
u8 second_H;
u8 second_L;

unsigned char y = 0;

//void Delay_s()		//@11.0592MHz
//{
//	unsigned char i, j;

//	_nop_();
//	i = 11;
//	j = 190;
//	do
//	{
//		while (--j);
//	} while (--i);
//}
//void delay(u16 T)
//{
//	while(T--)Delay1ms();
//}

void delay1ms(unsigned int n)
{
	unsigned char i, j;

	_nop_();
	i = 11;
	j = 190;
	do
	{
		while (--j);
	} while (--i);
}   //1ms

void delay1(int n)
{
	while(n--)delay1ms(1);
}


int Function_Key1(void)
{
//	if(Key_1 == 0)
//	{
//		delay(100);
//		if(Key_1 == 0)
//		{
//			return 1;
//		}
//	}
//	return 0;
			if(Key_1 == 0)
	{
		delay1(100);
		if(Key_1 == 0)
		{
			if(++y > 3)y = 0;datapros();
			while(Key_1 == 0);
		}
	}


}


int Function_Key2(void)
{
//	if(Key_2 == 0)
//	{
//		delay(100);
//		if(Key_2 == 0)
//		{
//			return 1;
//		}
//	}
			if(Key_2 == 0)
	{
		delay1(100);
		if(Key_2 == 0)
		{
			switch(y)
			{
				case 0:break;
				case 1:second_L++;break;
				case 2:minute_L++;break;
				case 3:if(hour_HS == 1){hour_HSL++;}
							 else{hour_L++;}
							 break;
				default:break;
			}
			//minute_L++;datapros();
			while(Key_2 == 0);
			
		}
	}
}

int Function_Key3(void)
{
	if(Key_3 == 0)
	{
		delay1(50);
		if(Key_3 == 0)
		{
			switch(y)
			{
				case 0:break;
				case 1:if(second_L == 0){second_H--;}
							 else{second_L--;}break;
				case 2:if(minute_L == 0){if(minute_H == 0){break;}
																else{minute_H--;minute_L = 9;}}
							 else{minute_L--;}break;
				case 3:if(hour_HS == 1)
							 {
									if(hour_HSL == 0){hour_H--;hour_L = 9;hour_HS = 0;}
									else{hour_HSL--;}
							 }
							 else
							 {
									if(hour_L == 0){if(hour_H == 0){break;}
																	else{hour_H--;hour_L = 9;}}
									else{hour_L--;}break;
								}break;
			}			
			//minute_L--;datapros();
			while(Key_3 == 0);
			
		}
	}
	//return 0;
}

